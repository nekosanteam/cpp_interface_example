#include "StubIF.h"

int main(void)
{
    work::StubIF iface;

    iface.process1(0);
    iface.process2(0);
}
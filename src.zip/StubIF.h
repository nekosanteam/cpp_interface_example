#ifndef STUB_IF_H_
#define STUB_IF_H_

namespace work {

class StubIF {
public:
    void process1(int arg);
    void process2(int arg);
};

}

#endif // STUB_IF_H_

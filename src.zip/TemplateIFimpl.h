#ifndef TEMPLATE_IF_IMPL_H_
#define TEMPLATE_IF_IMPL_H_

namespace work {

class TemplateIFimpl {
public:
    void operate1(int arg);
    void operate2(int arg);
};

}

#endif // TEMPLATE_IF_IMPL_H_
